import React, { useState } from 'react';
import { LayoutDashboard, Calendar, Users, DollarSign, Settings, Bell, Search, Menu, LogOut, Activity, User, X, Check, Moon, Sun } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { useTheme } from '../contexts/ThemeContext';

// Fix: Explicitly type the component props and use React.FC to support 'key' and other JSX attributes correctly
const SidebarItem: React.FC<{ icon: any, label: string, to: string, active: boolean }> = ({ icon: Icon, label, to, active }) => (
  <Link
    to={to}
    className={`group flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 relative overflow-hidden ${
      active 
        ? 'bg-sky-50 dark:bg-sky-900/20 text-sky-700 dark:text-sky-300 font-medium shadow-sm' 
        : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
    }`}
  >
    {active && <div className="absolute left-0 top-0 bottom-0 w-1 bg-sky-500 rounded-r-full animate-enter"></div>}
    <Icon size={20} className={`transition-transform duration-200 ${active ? 'scale-110' : 'group-hover:scale-110'}`} />
    <span>{label}</span>
  </Link>
);

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [showNotifications, setShowNotifications] = React.useState(false);
  const { logout, user } = useAuth();
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotification();
  const { isDarkMode, toggleTheme } = useTheme();

  const getInitials = (name: string) => {
    return name
        .split(' ')
        .map(n => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase();
  };

  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', to: '/' },
    { icon: Calendar, label: 'Agenda', to: '/agenda' },
    { icon: Users, label: 'Pacientes', to: '/pacientes' },
    { icon: DollarSign, label: 'Financeiro', to: '/financeiro' },
    { icon: User, label: 'Minha Conta', to: '/minha-conta' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col md:flex-row font-sans transition-colors duration-200">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 h-screen sticky top-0 z-30 transition-colors duration-200">
        <div className="p-6 border-b border-slate-100 dark:border-slate-700">
          <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="bg-sky-600 p-1.5 rounded-lg shadow-lg shadow-sky-200 dark:shadow-none">
              <Activity className="text-white" size={20} />
            </div>
            <span className="text-xl font-bold text-slate-800 dark:text-white tracking-tight">Psicogest</span>
          </Link>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1">
          {navItems.map((item) => (
            <SidebarItem
              key={item.to}
              icon={item.icon}
              label={item.label}
              to={item.to}
              active={location.pathname === item.to}
            />
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100 dark:border-slate-700">
          <button 
            onClick={logout}
            className="flex items-center gap-3 w-full px-4 py-3 text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors rounded-lg hover:bg-red-50 dark:hover:bg-red-900/10 group"
          >
            <LogOut size={20} className="transition-transform group-hover:-translate-x-1" />
            <span>Sair</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-40 transition-colors duration-200">
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="bg-sky-600 p-1.5 rounded-lg">
                <Activity className="text-white" size={20} />
            </div>
            <span className="text-lg font-bold text-slate-800 dark:text-white">Psicogest</span>
        </Link>
        <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2 text-slate-600 dark:text-slate-300">
          <Menu size={24} />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-white dark:bg-slate-800 animate-slide-in-right">
          <div className="p-4 flex justify-between items-center border-b border-slate-100 dark:border-slate-700">
             <span className="font-bold text-lg text-slate-800 dark:text-white">Menu</span>
             <button onClick={() => setMobileMenuOpen(false)} className="p-2 text-slate-500 dark:text-slate-400">
               <LogOut size={24} className="rotate-180" /> {/* Just a close icon placeholder */}
             </button>
          </div>
          <nav className="p-4 space-y-2">
             {navItems.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-lg ${
                    location.pathname === item.to 
                      ? 'bg-sky-50 dark:bg-sky-900/20 text-sky-700 dark:text-sky-300 font-medium' 
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <item.icon size={20} />
                  {item.label}
                </Link>
             ))}
             <button 
                onClick={() => {
                    setMobileMenuOpen(false);
                    logout();
                }}
                className="flex w-full items-center gap-3 px-4 py-3 rounded-lg text-lg text-slate-600 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400"
            >
                <LogOut size={20} />
                Sair
            </button>
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 transition-colors duration-200">
        {/* Header */}
        <header className="h-16 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-6 sticky top-0 z-20 transition-colors duration-200">
            <h1 className="text-xl font-semibold text-slate-800 dark:text-slate-100 capitalize animate-fade-in">
                {location.pathname === '/' ? 'Visão Geral' : location.pathname.replace('/', '').replace('-', ' ')}
            </h1>
            
            <div className="flex items-center gap-4">
                <div className="relative hidden sm:block">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                        type="text" 
                        placeholder="Buscar paciente..." 
                        className="pl-10 pr-4 py-2 border border-slate-200 dark:border-slate-600 rounded-full text-sm w-64 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 transition-shadow duration-200 focus:shadow-md"
                    />
                </div>

                {/* Theme Toggle */}
                <button
                    onClick={toggleTheme}
                    className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors hover:rotate-12 transform"
                    title={isDarkMode ? "Mudar para modo claro" : "Mudar para modo escuro"}
                >
                    {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
                </button>
                
                {/* Notification Bell */}
                <div className="relative">
                    <button 
                        className={`relative p-2 rounded-full transition-all duration-200 hover:scale-105 ${showNotifications ? 'bg-sky-50 dark:bg-sky-900/30 text-sky-600 dark:text-sky-300' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                        onClick={() => setShowNotifications(!showNotifications)}
                    >
                        <Bell size={20} className={unreadCount > 0 ? 'animate-pulse' : ''} />
                        {unreadCount > 0 && (
                            <span className="absolute top-1.5 right-2 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-slate-800"></span>
                        )}
                    </button>

                    {/* Notification Dropdown */}
                    {showNotifications && (
                        <>
                            <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)}></div>
                            <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-100 dark:border-slate-700 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                                <div className="p-3 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
                                    <h3 className="font-semibold text-slate-700 dark:text-slate-200 text-sm">Notificações</h3>
                                    {unreadCount > 0 && (
                                        <button onClick={markAllAsRead} className="text-xs text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 font-medium">
                                            Marcar todas como lidas
                                        </button>
                                    )}
                                </div>
                                <div className="max-h-96 overflow-y-auto">
                                    {notifications.length === 0 ? (
                                        <div className="p-8 text-center text-slate-400 dark:text-slate-500 text-sm">
                                            Nenhuma notificação.
                                        </div>
                                    ) : (
                                        <div className="divide-y divide-slate-50 dark:divide-slate-700">
                                            {notifications.map(notif => (
                                                <div 
                                                    key={notif.id} 
                                                    className={`p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors cursor-pointer ${!notif.read ? 'bg-sky-50/30 dark:bg-sky-900/20' : ''}`}
                                                    onClick={() => markAsRead(notif.id)}
                                                >
                                                    <div className="flex justify-between items-start mb-1">
                                                        <span className={`text-sm font-semibold ${notif.type === 'finance' ? 'text-emerald-700 dark:text-emerald-400' : notif.type === 'system' ? 'text-slate-700 dark:text-slate-300' : 'text-sky-700 dark:text-sky-400'}`}>
                                                            {notif.title}
                                                        </span>
                                                        <span className="text-xs text-slate-400 dark:text-slate-500">
                                                            {new Date(notif.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                                        </span>
                                                    </div>
                                                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{notif.message}</p>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </>
                    )}
                </div>

                <Link to="/minha-conta" className="w-8 h-8 bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-200 rounded-full flex items-center justify-center font-medium text-sm hover:ring-2 hover:ring-sky-200 dark:hover:ring-sky-700 transition-all cursor-pointer">
                    {getInitials(user.name)}
                </Link>
            </div>
        </header>

        {/* Page Content with Transition */}
        <div className="flex-1 p-6 overflow-auto" key={location.pathname}>
          <div className="max-w-7xl mx-auto animate-fade-in-up">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};