import React, { useState } from 'react';
import { Card, Button, Badge } from './UI';
import { DollarSign, TrendingUp, AlertCircle, Download, Filter, FileText, Printer, X, Activity, CreditCard, Loader2, FileSpreadsheet } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { useToast } from '../contexts/ToastContext';
import { Transaction } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { loadStripe } from '@stripe/stripe-js';

const STRIPE_PUBLIC_KEY = 'pk_test_TYooMQauvdEDq54NiTphI7jx';

const data = [
  { name: 'Jan', receita: 4000 },
  { name: 'Fev', receita: 3000 },
  { name: 'Mar', receita: 2000 },
  { name: 'Abr', receita: 2780 },
  { name: 'Mai', receita: 1890 },
  { name: 'Jun', receita: 2390 },
  { name: 'Jul', receita: 3490 },
  { name: 'Ago', receita: 4200 },
  { name: 'Set', receita: 5100 },
  { name: 'Out', receita: 6200 }, // Current month high
  { name: 'Nov', receita: 0 },
  { name: 'Dez', receita: 0 },
];

// Mock transactions with added type info needed for receipt
const transactions: Transaction[] = [
    { id: '1', description: 'Sessão de Psicoterapia', amount: 250, date: '2023-10-27', type: 'Income', status: 'Pago', patientName: 'Mariana Silva' } as any,
    { id: '2', description: 'Sessão de Psicoterapia', amount: 250, date: '2023-10-27', type: 'Income', status: 'Pendente', patientName: 'Carlos Oliveira' } as any,
    { id: '3', description: 'Sessão Online', amount: 200, date: '2023-10-26', type: 'Income', status: 'Pago', patientName: 'Ana Souza' } as any,
    { id: '4', description: 'Terapia Familiar', amount: 250, date: '2023-10-25', type: 'Income', status: 'Atrasado', patientName: 'Fernanda Costa' } as any,
];

// --- Receipt Modal Component ---
const ReceiptModal: React.FC<{ transaction: any; onClose: () => void }> = ({ transaction, onClose }) => {
    const { user } = useAuth();

    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-in fade-in duration-200">
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto flex flex-col">
                {/* Modal Header - No Print */}
                <div className="flex justify-between items-center p-4 border-b border-slate-100 dark:border-slate-700 no-print">
                    <h3 className="font-semibold text-slate-800 dark:text-slate-100">Gerar Recibo</h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                        <X size={20} />
                    </button>
                </div>

                {/* Printable Area - Always Light for printing */}
                <div id="receipt-area" className="p-12 bg-white text-slate-800">
                    <div className="border-2 border-slate-800 p-8 relative">
                        {/* Header */}
                        <div className="flex justify-between items-start mb-12">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Activity className="text-slate-800" size={24} />
                                    <span className="text-xl font-bold tracking-tight uppercase">Psicogest</span>
                                </div>
                                <p className="text-sm text-slate-600">{user.name}</p>
                                <p className="text-sm text-slate-600">Psicólogo(a) Clínica - CRP {user.crp}</p>
                                <p className="text-sm text-slate-600">{user.address}</p>
                            </div>
                            <div className="text-right">
                                <h1 className="text-3xl font-bold text-slate-800 mb-1">RECIBO</h1>
                                <p className="text-sm font-medium text-slate-500">#{transaction.id.padStart(6, '0')}</p>
                            </div>
                        </div>

                        {/* Amount */}
                        <div className="mb-8 bg-slate-50 p-4 text-center border border-slate-200">
                            <span className="text-sm font-semibold text-slate-500 uppercase block mb-1">Valor Total</span>
                            <span className="text-3xl font-bold text-slate-900">R$ {transaction.amount.toFixed(2).replace('.', ',')}</span>
                        </div>

                        {/* Body */}
                        <div className="space-y-6 text-lg leading-relaxed mb-12">
                            <p>
                                Recebi de <strong className="border-b border-slate-300 px-1">{transaction.patientName}</strong>
                            </p>
                            <p>
                                A importância de <strong>R$ {transaction.amount.toFixed(2).replace('.', ',')}</strong> referente a 
                                <span className="mx-1">{transaction.description}</span>
                                realizado(a) na data de {new Date(transaction.date.split('/').reverse().join('-')).toLocaleDateString()}.
                            </p>
                            <p>
                                E, para clareza, firmo o presente recibo dando plena quitação.
                            </p>
                        </div>

                        {/* Footer / Signature */}
                        <div className="flex justify-between items-end mt-16">
                            <div className="text-sm text-slate-500">
                                São Paulo, {new Date().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}.
                            </div>
                            <div className="text-center">
                                <div className="border-b border-slate-800 w-48 mb-2"></div>
                                <p className="font-semibold text-sm">{user.name}</p>
                                <p className="text-xs text-slate-500">Assinatura</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Modal Footer Actions - No Print */}
                <div className="p-4 border-t border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50 flex justify-end gap-3 no-print">
                    <Button variant="secondary" onClick={onClose}>Fechar</Button>
                    <Button onClick={handlePrint} className="gap-2">
                        <Printer size={18} /> Imprimir Recibo
                    </Button>
                </div>
            </div>
        </div>
    );
};

export const FinanceView: React.FC = () => {
    const { showToast } = useToast();
    const [selectedTransaction, setSelectedTransaction] = useState<any | null>(null);
    const [processingPaymentId, setProcessingPaymentId] = useState<string | null>(null);

    const handleOnlinePayment = async (transaction: any) => {
        setProcessingPaymentId(transaction.id);
        showToast('Iniciando processamento seguro...', 'info');

        try {
            const stripe = await loadStripe(STRIPE_PUBLIC_KEY);
            if (!stripe) throw new Error('Falha ao carregar Stripe');

            // Simulate API latency
            await new Promise(resolve => setTimeout(resolve, 2000));

            // In a real application, you would:
            // 1. Call your backend: POST /api/create-checkout-session { transactionId }
            // 2. Receive the { sessionId }
            // 3. Call stripe.redirectToCheckout({ sessionId })
            
            // Simulating redirection success
            showToast(`Redirecionando para o pagamento de R$ ${transaction.amount}...`, 'success');
            
            // Mock clearing state after "redirect"
            setTimeout(() => {
                setProcessingPaymentId(null);
            }, 1000);

        } catch (error) {
            console.error(error);
            showToast('Erro ao iniciar pagamento.', 'error');
            setProcessingPaymentId(null);
        }
    };

    const handleExportToSheets = () => {
        // Defines the header of the CSV
        const headers = ['ID', 'Data', 'Paciente', 'Descrição', 'Valor (R$)', 'Status', 'Tipo'];
        
        // Maps the transactions to CSV rows
        const rows = transactions.map(t => [
            t.id,
            t.date,
            t.patientName || '',
            t.description,
            t.amount.toString().replace('.', ','), // Format for PT-BR
            t.status,
            t.type === 'Income' ? 'Receita' : 'Despesa'
        ]);

        // Creates the CSV content with semi-colon separator (better for Excel/Sheets in BR)
        const csvContent = "\uFEFF" + 
            [headers, ...rows]
            .map(e => e.join(";"))
            .join("\n");

        // Creates a Blob and triggers download
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `relatorio_financeiro_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showToast('Planilha exportada com sucesso!', 'success');
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Controle Financeiro</h2>
                <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={handleExportToSheets}
                >
                    <FileSpreadsheet size={18} /> Exportar Planilha
                </Button>
            </div>

            {/* Top Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-gradient-to-br from-sky-500 to-sky-600 text-white border-none">
                    <div className="flex items-center gap-3 mb-4 opacity-90">
                        <div className="p-2 bg-white/20 rounded-lg"><DollarSign size={20} /></div>
                        <span className="font-medium">Receita Total (Out)</span>
                    </div>
                    <div className="text-3xl font-bold mb-1">R$ 6.200,00</div>
                    <div className="text-sm text-sky-100 flex items-center gap-1">
                        <TrendingUp size={14} /> +15% vs mês anterior
                    </div>
                </Card>
                <Card>
                     <div className="flex items-center gap-3 mb-4 text-slate-500 dark:text-slate-400">
                        <div className="p-2 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg"><AlertCircle size={20} /></div>
                        <span className="font-medium">A Receber</span>
                    </div>
                    <div className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-1">R$ 1.250,00</div>
                    <div className="text-sm text-slate-400">5 sessões pendentes</div>
                </Card>
                <Card>
                    <div className="flex items-center gap-3 mb-4 text-slate-500 dark:text-slate-400">
                        <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg"><TrendingUp size={20} /></div>
                        <span className="font-medium">Média por Sessão</span>
                    </div>
                    <div className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-1">R$ 245,00</div>
                    <div className="text-sm text-slate-400">Baseado em 25 atendimentos</div>
                </Card>
            </div>

            {/* Chart Area */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card title="Receita Mensal - 2023" className="lg:col-span-2">
                    <div className="h-72 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={data} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#94a3b8" strokeOpacity={0.2} />
                                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                                <Tooltip 
                                    cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }}
                                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', backgroundColor: 'var(--tooltip-bg, #fff)', color: 'var(--tooltip-text, #333)' }}
                                />
                                <Bar dataKey="receita" radius={[4, 4, 0, 0]}>
                                    {data.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.name === 'Out' ? '#0ea5e9' : '#cbd5e1'} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </Card>

                {/* Recent Transactions List */}
                <Card 
                    title="Transações Recentes" 
                    action={
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => showToast('Filtros em breve', 'info')}
                        >
                            <Filter size={16}/>
                        </Button>
                    }
                >
                    <div className="space-y-4">
                        {transactions.map(t => (
                            <div key={t.id} className="flex items-center justify-between py-2 border-b border-slate-50 dark:border-slate-700 last:border-0 hover:bg-slate-50 dark:hover:bg-slate-700/50 p-2 rounded transition-colors group">
                                <div onClick={() => showToast(`Detalhes da transação #${t.id}`, 'info')} className="cursor-pointer flex-1">
                                    <div className="font-medium text-slate-800 dark:text-slate-100">{t.patientName}</div>
                                    <div className="text-xs text-slate-400 dark:text-slate-500">{t.date} • {t.description}</div>
                                </div>
                                <div className="text-right flex flex-col items-end gap-1">
                                    <div className="font-semibold text-slate-700 dark:text-slate-200">R$ {t.amount}</div>
                                    <div className="flex items-center gap-2">
                                        <Badge color={t.status === 'Pago' ? 'green' : t.status === 'Pendente' ? 'yellow' : 'red'}>
                                            {t.status}
                                        </Badge>
                                        
                                        {/* Actions based on status */}
                                        {t.status === 'Pago' && (
                                            <button 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setSelectedTransaction(t);
                                                }}
                                                className="p-1 text-slate-400 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/30 rounded transition-colors"
                                                title="Gerar Recibo"
                                            >
                                                <FileText size={16} />
                                            </button>
                                        )}

                                        {(t.status === 'Pendente' || t.status === 'Atrasado') && (
                                            <Button 
                                                size="sm"
                                                variant="primary"
                                                className="px-2 py-1 h-7 text-xs gap-1 ml-1"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleOnlinePayment(t);
                                                }}
                                                disabled={processingPaymentId === t.id}
                                                title="Pagar Online com Stripe"
                                            >
                                                {processingPaymentId === t.id ? (
                                                    <Loader2 size={12} className="animate-spin" />
                                                ) : (
                                                    <>
                                                        <CreditCard size={12} /> Pagar
                                                    </>
                                                )}
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                     <Button 
                        variant="ghost" 
                        className="w-full mt-4 text-xs"
                        onClick={() => showToast('Carregando histórico completo...', 'info')}
                    >
                        Ver todas as transações
                    </Button>
                </Card>
            </div>

            {/* Receipt Modal */}
            {selectedTransaction && (
                <ReceiptModal 
                    transaction={selectedTransaction} 
                    onClose={() => setSelectedTransaction(null)} 
                />
            )}
        </div>
    );
};