import { GoogleGenAI } from "@google/genai";

// Fix: Always use new GoogleGenAI({apiKey: process.env.API_KEY}); as per guidelines.
// Assume process.env.API_KEY is pre-configured and valid.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const refineClinicalNote = async (roughNotes: string): Promise<string> => {
  try {
    const model = 'gemini-3-flash-preview';
    const prompt = `
      Atue como um assistente clínico profissional para psicólogos.
      Sua tarefa é reescrever e estruturar as seguintes anotações brutas de uma sessão de terapia.
      
      Diretrizes:
      1. Use uma linguagem formal, clínica e objetiva.
      2. Estruture o texto em parágrafos claros ou tópicos se apropriado (ex: Queixa Principal, Intervenções, Observações).
      3. Mantenha o sigilo e a neutralidade.
      4. Corrija erros gramaticais.
      5. O idioma deve ser Português do Brasil.

      Anotações Brutas:
      "${roughNotes}"
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Não foi possível gerar a resposta.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Erro ao processar a nota com inteligência artificial.";
  }
};