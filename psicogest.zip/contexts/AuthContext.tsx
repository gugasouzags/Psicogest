import React, { createContext, useContext, useState, useEffect } from 'react';
import { PlanType, SubscriptionStatus } from '../types';

// Define UserProfile interface
export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  crp: string;
  specialty: string;
  address: string;
  plan: PlanType;
  subscriptionStatus: SubscriptionStatus;
  stripeCustomerId?: string;
}

const DEFAULT_USER: UserProfile = {
  name: 'Dra. Roberta Silva',
  email: 'roberta.silva@psicogest.com',
  phone: '(11) 99876-5432',
  crp: '06/12345',
  specialty: 'Psicologia Clínica / TCC',
  address: 'Rua das Flores, 123 - Sala 402, São Paulo - SP',
  plan: 'free', // Default to free to show the upgrade flow
  subscriptionStatus: 'inactive'
};

interface AuthContextType {
  isAuthenticated: boolean;
  user: UserProfile;
  updateUser: (data: Partial<UserProfile>) => void;
  login: (email: string, pass: string) => Promise<void>;
  logout: () => void;
  upgradeToPro: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<UserProfile>(DEFAULT_USER);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check local storage on load
    const storedAuth = localStorage.getItem('psicogest_auth');
    if (storedAuth === 'true') {
      setIsAuthenticated(true);
    }
    
    // Load persisted user data if exists
    const storedUser = localStorage.getItem('psicogest_user');
    if (storedUser) {
        try {
            setUser(JSON.parse(storedUser));
        } catch (e) {
            console.error("Failed to parse user profile", e);
        }
    }
    
    setLoading(false);
  }, []);

  const updateUser = (data: Partial<UserProfile>) => {
      setUser(prev => {
          const updated = { ...prev, ...data };
          localStorage.setItem('psicogest_user', JSON.stringify(updated));
          return updated;
      });
  };

  const login = async (email: string, pass: string): Promise<void> => {
    // Mock login logic
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Allow any login for demo purposes, or enforce specific credentials if needed
        if (email && pass) {
          localStorage.setItem('psicogest_auth', 'true');
          setIsAuthenticated(true);
          resolve();
        } else {
          reject(new Error('Credenciais inválidas.'));
        }
      }, 1000);
    });
  };

  const logout = () => {
    localStorage.removeItem('psicogest_auth');
    setIsAuthenticated(false);
  };

  const upgradeToPro = () => {
      updateUser({
          plan: 'pro',
          subscriptionStatus: 'active'
      });
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, updateUser, login, logout, upgradeToPro, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};