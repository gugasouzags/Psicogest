import React, { createContext, useContext, useState, useEffect } from 'react';
import { NotificationSettings, AppNotification } from '../types';
import { useToast } from './ToastContext';

interface NotificationContextType {
  settings: NotificationSettings;
  updateSettings: (newSettings: NotificationSettings) => void;
  notifications: AppNotification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  requestPushPermission: () => Promise<boolean>;
  triggerTestNotification: () => void;
  notifyAdmin: (title: string, message: string) => void;
}

const DEFAULT_SETTINGS: NotificationSettings = {
  psychologist: {
    enabled: true,
    advanceTime: 15, // 15 minutes before
    channel: 'push',
    adminPhoneNumber: '5571984793976' // Default number provided by user (BR code added)
  },
  patient: {
    enabled: true,
    advanceTime: 1440, // 24 hours before
    channel: 'whatsapp'
  }
};

const MOCK_NOTIFICATIONS: AppNotification[] = [
  { id: '1', title: 'Sessão em 15 min', message: 'Atendimento com Mariana Silva (Online) começa em breve.', date: new Date().toISOString(), read: false, type: 'appointment' },
  { id: '2', title: 'Pagamento Recebido', message: 'Carlos Oliveira realizou o pagamento via PIX.', date: new Date(Date.now() - 3600000).toISOString(), read: true, type: 'finance' },
];

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<NotificationSettings>(DEFAULT_SETTINGS);
  const [notifications, setNotifications] = useState<AppNotification[]>(MOCK_NOTIFICATIONS);
  const { showToast } = useToast();

  const unreadCount = notifications.filter(n => !n.read).length;

  const updateSettings = (newSettings: NotificationSettings) => {
    setSettings(newSettings);
    showToast('Configurações de notificação salvas.', 'success');
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const requestPushPermission = async (): Promise<boolean> => {
    if (!('Notification' in window)) {
      showToast('Este navegador não suporta notificações.', 'error');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      showToast('Notificações ativadas com sucesso!', 'success');
      return true;
    } else {
      showToast('Permissão para notificações negada.', 'info');
      return false;
    }
  };

  const notifyAdmin = (title: string, message: string) => {
      // 1. Internal App Notification
      const newNotif: AppNotification = {
          id: Math.random().toString(36).substr(2, 9),
          title: title,
          message: message,
          date: new Date().toISOString(),
          read: false,
          type: 'system'
      };
      setNotifications(prev => [newNotif, ...prev]);

      // 2. WhatsApp Notification (if number exists)
      if (settings.psychologist.adminPhoneNumber) {
          const formattedMessage = `*Psicogest - Nova Notificação*\n\n*${title}*\n${message}`;
          const url = `https://wa.me/${settings.psychologist.adminPhoneNumber}?text=${encodeURIComponent(formattedMessage)}`;
          
          // Open in new tab
          window.open(url, '_blank');
      }
  };

  const triggerTestNotification = async () => {
    const hasPermission = await requestPushPermission();
    
    // Test WhatsApp integration
    notifyAdmin('Teste de Sistema', `Este é um teste de notificação enviado às ${new Date().toLocaleTimeString()}.`);

    // Trigger Browser Push if allowed
    if (hasPermission && settings.psychologist.enabled) {
      new Notification('Psicogest - Lembrete', {
        body: `Sessão com Paciente Exemplo em ${settings.psychologist.advanceTime} minutos.`,
        // icon: '/favicon.ico' 
      });
    }
  };

  return (
    <NotificationContext.Provider value={{
      settings,
      updateSettings,
      notifications,
      unreadCount,
      markAsRead,
      markAllAsRead,
      requestPushPermission,
      triggerTestNotification,
      notifyAdmin
    }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};