import React, { useState, useEffect } from 'react';
import { Card, Button, Input, Badge } from './UI';
import { User, Mail, Phone, MapPin, Shield, CreditCard, Bell, Camera, Save, Lock, Smartphone, Clock, Check, Star, Zap, ExternalLink } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useNotification } from '../contexts/NotificationContext';
import { useAuth, UserProfile } from '../contexts/AuthContext';
import { loadStripe } from '@stripe/stripe-js';

// Replace with your actual Stripe publishable key
const STRIPE_PUBLIC_KEY = 'pk_test_TYooMQauvdEDq54NiTphI7jx'; 

export const MyAccount: React.FC = () => {
  const { showToast } = useToast();
  const { settings, updateSettings, requestPushPermission, triggerTestNotification } = useNotification();
  const { user, updateUser, upgradeToPro } = useAuth();
  const [loading, setLoading] = useState(false);
  const [processingSubscription, setProcessingSubscription] = useState(false);
  
  // Local state for form editing prevents global updates while typing
  const [formData, setFormData] = useState<UserProfile>(user);

  // Sync local state if global user changes (e.g. initial load)
  useEffect(() => {
    setFormData(user);
  }, [user]);

  const handleInputChange = (field: keyof UserProfile, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    setLoading(true);
    // Simulate API call and update global context
    setTimeout(() => {
      updateUser(formData);
      setLoading(false);
      showToast('Alterações salvas e perfil atualizado!', 'success');
    }, 800);
  };

  const handleStripeSubscribe = async () => {
      setProcessingSubscription(true);
      showToast('Redirecionando para o Checkout do Stripe...', 'info');

      try {
          const stripe = await loadStripe(STRIPE_PUBLIC_KEY);
          if (!stripe) throw new Error('Falha ao carregar Stripe');

          // IN A REAL APP:
          // 1. Call your backend to create a Checkout Session
          // const response = await fetch('/api/create-checkout-session', { method: 'POST' });
          // const session = await response.json();
          // 2. Redirect to Stripe
          // const result = await stripe.redirectToCheckout({ sessionId: session.id });

          // FOR THIS DEMO (Simulating success after delay):
          setTimeout(() => {
              upgradeToPro();
              setProcessingSubscription(false);
              showToast('Assinatura realizada com sucesso! Bem-vindo ao Pro.', 'success');
          }, 2500);

      } catch (error) {
          console.error(error);
          showToast('Erro ao processar pagamento.', 'error');
          setProcessingSubscription(false);
      }
  };

  const handleManageSubscription = () => {
      showToast('Redirecionando para o Portal do Cliente Stripe...', 'info');
      // In real app: window.location.href = billingPortalUrl;
  };

  const handlePsychologistSettingChange = (field: string, value: any) => {
    updateSettings({
        ...settings,
        psychologist: {
            ...settings.psychologist,
            [field]: value
        }
    });
  };

  const handlePatientSettingChange = (field: string, value: any) => {
    updateSettings({
        ...settings,
        patient: {
            ...settings.patient,
            [field]: value
        }
    });
  };

  // Helper to get initials
  const getInitials = (name: string) => {
      return name
        .split(' ')
        .map(n => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Minha Conta</h2>
        <Button onClick={handleSave} disabled={loading} className="gap-2">
            {loading ? 'Salvando...' : <><Save size={18} /> Salvar Alterações</>}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Avatar & Main Info */}
        <div className="space-y-6">
            <Card className="text-center pb-8">
                <div className="relative inline-block mx-auto mb-4">
                    <div className="w-32 h-32 rounded-full bg-sky-100 dark:bg-sky-900/50 border-4 border-white dark:border-slate-700 shadow-lg flex items-center justify-center text-sky-700 dark:text-sky-300 text-3xl font-bold overflow-hidden">
                        {getInitials(formData.name)}
                    </div>
                    <button 
                        className="absolute bottom-0 right-0 p-2 bg-sky-600 text-white rounded-full hover:bg-sky-700 transition-colors shadow-md border-2 border-white dark:border-slate-800"
                        onClick={() => showToast('Funcionalidade de upload em breve', 'info')}
                    >
                        <Camera size={16} />
                    </button>
                </div>
                <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">{formData.name}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">{formData.specialty}</p>
                <div className="flex justify-center gap-2">
                    <Badge color={user.plan === 'pro' ? 'blue' : 'gray'}>
                        {user.plan === 'pro' ? 'Plano Profissional' : 'Plano Gratuito'}
                    </Badge>
                    <Badge color={user.subscriptionStatus === 'active' ? 'green' : 'yellow'}>
                        {user.subscriptionStatus === 'active' ? 'Ativo' : 'Inativo'}
                    </Badge>
                </div>
            </Card>

            {/* Subscription Card - DYNAMIC */}
            <Card title="Assinatura e Cobrança">
                {user.plan === 'free' ? (
                    <div className="space-y-4">
                         <div className="bg-gradient-to-br from-sky-50 to-white dark:from-sky-900/40 dark:to-slate-800 border border-sky-100 dark:border-sky-800 rounded-xl p-5 relative overflow-hidden">
                             <div className="absolute top-0 right-0 bg-sky-500 text-white text-[10px] px-2 py-1 rounded-bl-lg font-bold">RECOMENDADO</div>
                             <div className="flex items-baseline gap-1 mb-2">
                                <span className="text-2xl font-bold text-slate-800 dark:text-white">R$ 89,90</span>
                                <span className="text-sm text-slate-500 dark:text-slate-400">/mês</span>
                             </div>
                             <h4 className="font-bold text-sky-700 dark:text-sky-400 mb-3 flex items-center gap-2">
                                <Zap size={16} className="fill-current" /> Plano Profissional
                             </h4>
                             <ul className="space-y-2 mb-4">
                                <li className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500"/> Pacientes Ilimitados</li>
                                <li className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500"/> IA para Evoluções</li>
                                <li className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500"/> Gestão Financeira Completa</li>
                             </ul>
                             <Button 
                                className="w-full shadow-md shadow-sky-200 dark:shadow-none" 
                                onClick={handleStripeSubscribe}
                                disabled={processingSubscription}
                            >
                                {processingSubscription ? 'Processando...' : 'Assinar Agora'}
                             </Button>
                             <div className="flex items-center justify-center gap-1 mt-3 text-[10px] text-slate-400">
                                <Lock size={10} /> Pagamento seguro via Stripe
                             </div>
                         </div>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg border border-slate-100 dark:border-slate-600">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-white dark:bg-slate-700 rounded-md shadow-sm text-sky-600 dark:text-sky-400">
                                    <CreditCard size={20} />
                                </div>
                                <div>
                                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Visa final 4242</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Próxima cobrança: 27/11/2023</p>
                                </div>
                            </div>
                            <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-1 rounded-full">Ativo</span>
                        </div>
                        
                        <Button variant="outline" size="sm" className="w-full text-xs gap-2" onClick={handleManageSubscription}>
                            Gerenciar Assinatura <ExternalLink size={12}/>
                        </Button>
                        <p className="text-[10px] text-center text-slate-400">
                            Gerenciado via Stripe Customer Portal
                        </p>
                    </div>
                )}
            </Card>
        </div>

        {/* Right Column: Forms */}
        <div className="lg:col-span-2 space-y-6">
            
            {/* Notification Configuration */}
            <Card 
                title="Lembretes e Notificações" 
                action={
                    <Button variant="ghost" size="sm" onClick={triggerTestNotification}>
                        Testar Notificação
                    </Button>
                }
            >
                <div className="space-y-6">
                    {/* Psychologist Settings */}
                    <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg border border-slate-100 dark:border-slate-600">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-white dark:bg-slate-700 rounded-md text-sky-600 dark:text-sky-400 shadow-sm"><Bell size={18}/></div>
                                <div>
                                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Para mim (Psicólogo)</h4>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Alertas sobre início de sessões</p>
                                </div>
                            </div>
                            <div className="relative inline-block w-10 align-middle select-none transition duration-200 ease-in">
                                <input 
                                    type="checkbox" 
                                    checked={settings.psychologist.enabled}
                                    onChange={(e) => handlePsychologistSettingChange('enabled', e.target.checked)}
                                    id="toggle-psy" 
                                    className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer border-sky-600 right-0 checked:right-0"
                                />
                                <label htmlFor="toggle-psy" className={`toggle-label block overflow-hidden h-5 rounded-full cursor-pointer ${settings.psychologist.enabled ? 'bg-sky-600' : 'bg-slate-300 dark:bg-slate-600'}`}></label>
                            </div>
                        </div>

                        {settings.psychologist.enabled && (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-2">
                                <div>
                                    <label className="text-xs font-medium text-slate-500 dark:text-slate-400 block mb-1">Antecedência do Lembrete</label>
                                    <div className="relative">
                                        <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                        <select 
                                            value={settings.psychologist.advanceTime}
                                            onChange={(e) => handlePsychologistSettingChange('advanceTime', parseInt(e.target.value))}
                                            className="w-full pl-10 pr-3 py-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                                        >
                                            <option value={5}>5 minutos antes</option>
                                            <option value={10}>10 minutos antes</option>
                                            <option value={15}>15 minutos antes</option>
                                            <option value={30}>30 minutos antes</option>
                                            <option value={60}>1 hora antes</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label className="text-xs font-medium text-slate-500 dark:text-slate-400 block mb-1">Canal de Envio</label>
                                    <div className="relative">
                                        <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                        <select 
                                            value={settings.psychologist.channel}
                                            onChange={(e) => handlePsychologistSettingChange('channel', e.target.value)}
                                            className="w-full pl-10 pr-3 py-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                                        >
                                            <option value="push">Notificação Push (Navegador)</option>
                                            <option value="email">Email</option>
                                            <option value="both">Ambos</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="md:col-span-2">
                                     <button 
                                        onClick={requestPushPermission}
                                        className="text-xs text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 underline flex items-center gap-1"
                                    >
                                        <Check size={12}/> Verificar permissões do navegador
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Patient Settings */}
                    <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg border border-slate-100 dark:border-slate-600">
                         <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-white dark:bg-slate-700 rounded-md text-emerald-600 dark:text-emerald-400 shadow-sm"><User size={18}/></div>
                                <div>
                                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Para o Paciente</h4>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Lembretes automáticos de agendamento</p>
                                </div>
                            </div>
                            <div className="relative inline-block w-10 align-middle select-none transition duration-200 ease-in">
                                <input 
                                    type="checkbox" 
                                    checked={settings.patient.enabled}
                                    onChange={(e) => handlePatientSettingChange('enabled', e.target.checked)}
                                    id="toggle-pat" 
                                    className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer border-sky-600 right-0"
                                />
                                <label htmlFor="toggle-pat" className={`toggle-label block overflow-hidden h-5 rounded-full cursor-pointer ${settings.patient.enabled ? 'bg-sky-600' : 'bg-slate-300 dark:bg-slate-600'}`}></label>
                            </div>
                        </div>
                        
                        {settings.patient.enabled && (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-2">
                                <div>
                                    <label className="text-xs font-medium text-slate-500 dark:text-slate-400 block mb-1">Quando enviar</label>
                                    <div className="relative">
                                        <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                        <select 
                                            value={settings.patient.advanceTime}
                                            onChange={(e) => handlePatientSettingChange('advanceTime', parseInt(e.target.value))}
                                            className="w-full pl-10 pr-3 py-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                                        >
                                            <option value={120}>2 horas antes</option>
                                            <option value={1440}>24 horas antes (Dia anterior)</option>
                                            <option value={2880}>48 horas antes</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label className="text-xs font-medium text-slate-500 dark:text-slate-400 block mb-1">Canal Principal</label>
                                    <div className="relative">
                                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                        <select 
                                            value={settings.patient.channel}
                                            onChange={(e) => handlePatientSettingChange('channel', e.target.value)}
                                            className="w-full pl-10 pr-3 py-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                                        >
                                            <option value="whatsapp">WhatsApp (Automático)</option>
                                            <option value="email">Email</option>
                                            <option value="sms">SMS</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </Card>

            {/* Personal Information */}
            <Card title="Informações Pessoais">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <Input 
                            label="Nome Completo"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                        />
                    </div>
                     <div className="space-y-1">
                        <Input 
                            label="Registro Profissional (CRP)"
                            value={formData.crp}
                            onChange={(e) => handleInputChange('crp', e.target.value)}
                        />
                    </div>
                    <div className="space-y-1">
                        <Input 
                            label="Email"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                        />
                    </div>
                    <div className="space-y-1">
                         <Input 
                            label="Telefone"
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                        />
                    </div>
                </div>
            </Card>

            {/* Clinic Details */}
            <Card title="Dados do Consultório">
                 <div className="space-y-4">
                    <div className="space-y-1">
                        <Input 
                            label="Endereço Completo"
                            value={formData.address}
                            onChange={(e) => handleInputChange('address', e.target.value)}
                        />
                    </div>
                    <div className="p-4 bg-sky-50 dark:bg-sky-900/20 rounded-lg border border-sky-100 dark:border-sky-800 flex gap-3">
                         <div className="bg-white dark:bg-slate-800 p-2 rounded-full h-fit text-sky-600 dark:text-sky-400 shadow-sm"><Save size={16}/></div>
                         <div>
                            <h4 className="text-sm font-bold text-sky-800 dark:text-sky-300">Backup Automático</h4>
                            <p className="text-xs text-sky-700 dark:text-sky-400 mt-1">Seus dados clínicos são criptografados e salvos automaticamente na nuvem a cada alteração.</p>
                         </div>
                    </div>
                 </div>
            </Card>

            {/* Security Settings */}
            <Card title="Segurança">
                <div className="space-y-4 divide-y divide-slate-100 dark:divide-slate-700">
                    <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-md text-slate-600 dark:text-slate-400"><Lock size={18}/></div>
                            <div>
                                <p className="font-medium text-slate-800 dark:text-slate-200 text-sm">Senha</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Última alteração há 3 meses</p>
                            </div>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => showToast('Link de redefinição enviado', 'info')}>Alterar Senha</Button>
                    </div>
                </div>
            </Card>
        </div>
      </div>
    </div>
  );
};