import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Button, TextArea } from './UI';
import { ChevronLeft, Calendar, Clock, User, DollarSign, Video, MapPin, Save } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useNotification } from '../contexts/NotificationContext';

// Mock patients for the dropdown
const PATIENTS = [
  { id: '1', name: 'Mariana Silva' },
  { id: '2', name: 'Carlos Oliveira' },
  { id: '3', name: 'Fernanda Costa' },
  { id: '4', name: 'João Pedro' },
];

export const NewAppointment: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { notifyAdmin } = useNotification();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    patientId: '',
    date: new Date().toISOString().split('T')[0], // Today YYYY-MM-DD
    time: '09:00',
    duration: '50',
    type: 'Online',
    value: '250',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
        setLoading(false);
        showToast('Agendamento criado! Enviando notificação WhatsApp...', 'success');
        
        // Find patient name for notification
        const patientName = PATIENTS.find(p => p.id === formData.patientId)?.name || 'Paciente';

        // Trigger Notification
        notifyAdmin(
            'Novo Agendamento Criado',
            `📅 Paciente: ${patientName}\n🕒 Data: ${new Date(formData.date).toLocaleDateString('pt-BR')} às ${formData.time}\n💻 Tipo: ${formData.type}\n💰 Valor: R$ ${formData.value}`
        );

        navigate('/agenda');
    }, 1000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-500 dark:text-slate-400">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Novo Agendamento</h2>
      </div>

      <div className="max-w-2xl mx-auto">
        <Card>
            <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Patient Selection */}
                <div className="space-y-1">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Paciente</label>
                    <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <select 
                            className="w-full pl-10 pr-3 py-2 border border-slate-200 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 appearance-none"
                            value={formData.patientId}
                            onChange={e => setFormData({...formData, patientId: e.target.value})}
                            required
                        >
                            <option value="" disabled>Selecione um paciente...</option>
                            {PATIENTS.map(p => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Date and Time */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Data</label>
                        <div className="relative">
                            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                            <input 
                                type="date"
                                className="w-full pl-10 pr-3 py-2 border border-slate-200 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                                value={formData.date}
                                onChange={e => setFormData({...formData, date: e.target.value})}
                                required
                            />
                        </div>
                    </div>
                    <div className="space-y-1">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Horário</label>
                        <div className="relative">
                            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                            <input 
                                type="time"
                                className="w-full pl-10 pr-3 py-2 border border-slate-200 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                                value={formData.time}
                                onChange={e => setFormData({...formData, time: e.target.value})}
                                required
                            />
                        </div>
                    </div>
                </div>

                {/* Duration and Value */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div className="space-y-1">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Duração</label>
                        <select 
                            className="w-full px-3 py-2 border border-slate-200 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                            value={formData.duration}
                            onChange={e => setFormData({...formData, duration: e.target.value})}
                        >
                            <option value="30">30 minutos</option>
                            <option value="50">50 minutos (Padrão)</option>
                            <option value="60">1 hora</option>
                            <option value="90">1 hora e 30 min</option>
                        </select>
                    </div>
                    <div className="space-y-1">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Valor da Sessão (R$)</label>
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                            <input 
                                type="number"
                                className="w-full pl-10 pr-3 py-2 border border-slate-200 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                                value={formData.value}
                                onChange={e => setFormData({...formData, value: e.target.value})}
                            />
                        </div>
                    </div>
                </div>

                {/* Type Selection */}
                <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Modalidade</label>
                    <div className="grid grid-cols-2 gap-4">
                        <button
                            type="button"
                            onClick={() => setFormData({...formData, type: 'Online'})}
                            className={`flex items-center justify-center gap-2 p-3 rounded-lg border transition-all ${
                                formData.type === 'Online' 
                                ? 'bg-sky-50 dark:bg-sky-900/30 border-sky-500 text-sky-700 dark:text-sky-300 ring-1 ring-sky-500' 
                                : 'border-slate-200 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                            }`}
                        >
                            <Video size={20} />
                            <span className="font-medium">Online</span>
                        </button>
                        <button
                            type="button"
                            onClick={() => setFormData({...formData, type: 'Presencial'})}
                            className={`flex items-center justify-center gap-2 p-3 rounded-lg border transition-all ${
                                formData.type === 'Presencial' 
                                ? 'bg-sky-50 dark:bg-sky-900/30 border-sky-500 text-sky-700 dark:text-sky-300 ring-1 ring-sky-500' 
                                : 'border-slate-200 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                            }`}
                        >
                            <MapPin size={20} />
                            <span className="font-medium">Presencial</span>
                        </button>
                    </div>
                </div>

                {/* Notes */}
                <TextArea 
                    label="Observações (Opcional)" 
                    placeholder="Alguma nota específica para este agendamento..."
                    rows={3}
                    value={formData.notes}
                    onChange={e => setFormData({...formData, notes: e.target.value})}
                />

                <div className="pt-4 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-700">
                    <Button type="button" variant="secondary" onClick={() => navigate(-1)}>Cancelar</Button>
                    <Button type="submit" disabled={loading} className="gap-2 min-w-[120px]">
                        {loading ? 'Salvando...' : <><Save size={18} /> Agendar</>}
                    </Button>
                </div>

            </form>
        </Card>
      </div>
    </div>
  );
};