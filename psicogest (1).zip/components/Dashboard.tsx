import React from 'react';
import { Card, Button, Badge } from './UI';
import { Calendar, Users, DollarSign, Clock, Video, MapPin } from 'lucide-react';
import { Appointment, AppointmentStatus, PaymentStatus } from '../types';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';

const mockAppointments: Appointment[] = [
    { id: '1', patientId: 'p1', patientName: 'Mariana Silva', date: '2023-10-27', startTime: '09:00', endTime: '09:50', type: 'Online', status: AppointmentStatus.Scheduled, paymentStatus: PaymentStatus.Paid, value: 250 },
    { id: '2', patientId: 'p2', patientName: 'Carlos Oliveira', date: '2023-10-27', startTime: '10:00', endTime: '10:50', type: 'Presencial', status: AppointmentStatus.Scheduled, paymentStatus: PaymentStatus.Pending, value: 250 },
    { id: '3', patientId: 'p3', patientName: 'Fernanda Costa', date: '2023-10-27', startTime: '14:00', endTime: '14:50', type: 'Online', status: AppointmentStatus.Scheduled, paymentStatus: PaymentStatus.Overdue, value: 250 },
];

const StatCard = ({ icon: Icon, label, value, trend, trendUp, delayClass }: { icon: any, label: string, value: string, trend?: string, trendUp?: boolean, delayClass?: string }) => (
    <Card className={`flex flex-col gap-1 relative overflow-hidden group animate-fade-in-up ${delayClass}`}>
        <div className="flex items-center gap-3 mb-2">
            <div className={`p-2 rounded-lg transition-colors ${trendUp === undefined ? 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300' : 'bg-sky-50 text-sky-600 dark:bg-sky-900/30 dark:text-sky-300 group-hover:bg-sky-100 dark:group-hover:bg-sky-900/50'}`}>
                <Icon size={20} className="transition-transform duration-300 group-hover:scale-110" />
            </div>
            <span className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</span>
        </div>
        <div className="text-2xl font-bold text-slate-800 dark:text-slate-100">{value}</div>
        {trend && (
            <div className={`text-xs mt-2 ${trendUp ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                {trend}
            </div>
        )}
    </Card>
);

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 animate-fade-in">
        <div>
            <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
              Olá, {user.name ? user.name.split(' ')[0] : 'Doutor(a)'}! 👋
            </h2>
            <p className="text-slate-500 dark:text-slate-400">Aqui está o resumo da sua clínica hoje.</p>
        </div>
        <div className="flex gap-2">
            <Button 
                variant="secondary" 
                size="sm"
                onClick={() => {
                    navigate('/pacientes');
                    showToast('Selecione "Novo Paciente" na lista.', 'info');
                }}
            >
                Adicionar Paciente
            </Button>
            <Button 
                size="sm"
                onClick={() => navigate('/novo-agendamento')}
            >
                Novo Agendamento
            </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Calendar} label="Sessões Hoje" value="6" trend="+2 desde ontem" trendUp={true} delayClass="" />
        <StatCard icon={Users} label="Pacientes Ativos" value="24" trend="+3 este mês" trendUp={true} delayClass="delay-100" />
        <StatCard icon={DollarSign} label="Faturamento (Mês)" value="R$ 12.450" trend="+12% vs mês anterior" trendUp={true} delayClass="delay-200" />
        <StatCard icon={Clock} label="Pagamentos Pendentes" value="R$ 750" trend="2 pacientes" trendUp={false} delayClass="delay-300" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Next Appointment - High Priority */}
        <div className="lg:col-span-2 space-y-6 animate-fade-in-up delay-200">
            <Card 
                title="Próximos Atendimentos" 
                action={
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs"
                        onClick={() => navigate('/agenda')}
                    >
                        Ver agenda completa
                    </Button>
                }
            >
                <div className="space-y-4">
                    {mockAppointments.map((apt) => (
                        <div key={apt.id} className="group flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-xl border border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 hover:border-sky-100 dark:hover:border-slate-600 hover:shadow-md transition-all duration-300 transform hover:-translate-y-0.5">
                            <div className="flex items-center gap-4">
                                <div className="flex flex-col items-center justify-center w-14 h-14 bg-white dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 shadow-sm text-center transition-colors group-hover:border-sky-200 dark:group-hover:border-sky-800">
                                    <span className="text-xs font-semibold text-slate-400 dark:text-slate-300">{apt.startTime}</span>
                                    <span className="text-xs text-slate-300 dark:text-slate-500">até</span>
                                    <span className="text-xs font-semibold text-slate-400 dark:text-slate-300">{apt.endTime}</span>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-slate-800 dark:text-slate-100 group-hover:text-sky-700 dark:group-hover:text-sky-400 transition-colors">{apt.patientName}</h4>
                                    <div className="flex items-center gap-2 mt-1">
                                        <Badge color="blue">{apt.type}</Badge>
                                        <span className="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1">
                                            {apt.type === 'Online' ? <Video size={12}/> : <MapPin size={12}/>}
                                            {apt.type === 'Online' ? 'Google Meet' : 'Consultório 2'}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center gap-3 mt-4 sm:mt-0 w-full sm:w-auto opacity-90 group-hover:opacity-100 transition-opacity">
                                <Button 
                                    variant="secondary" 
                                    size="sm" 
                                    className="flex-1 sm:flex-none"
                                    onClick={() => {
                                        navigate('/pacientes');
                                        showToast(`Visualizando prontuário de ${apt.patientName}`, 'info');
                                    }}
                                >
                                    Detalhes
                                </Button>
                                {apt.type === 'Online' && (
                                    <Button 
                                        size="sm" 
                                        className="flex-1 sm:flex-none gap-2 animate-pulse-slow"
                                        onClick={() => showToast('Iniciando Google Meet...', 'success')}
                                    >
                                        <Video size={16} /> Entrar
                                    </Button>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </Card>

            <Card title="Evolução Financeira Recente">
                 {/* Simple placeholder for a chart */}
                 <div className="h-48 flex items-end justify-between gap-2 pt-4 px-2">
                    {[65, 40, 75, 55, 80, 60, 90].map((h, i) => (
                        <div key={i} className="w-full bg-sky-50 dark:bg-sky-900/20 rounded-t-lg relative group hover:bg-sky-100 dark:hover:bg-sky-900/40 transition-colors cursor-pointer" title={`R$ ${h * 100}`}>
                             <div 
                                className="absolute bottom-0 left-0 right-0 bg-sky-500 dark:bg-sky-600 rounded-t-lg transition-all duration-1000 ease-out origin-bottom" 
                                style={{ height: `${h}%`, animation: `fadeInUp 1s ease-out ${i * 100}ms backwards` }}
                             ></div>
                        </div>
                    ))}
                 </div>
                 <div className="flex justify-between mt-2 text-xs text-slate-400 dark:text-slate-500">
                    <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Dom</span>
                 </div>
            </Card>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6 animate-fade-in-up delay-300">
            <Card title="Lembretes Rápidos">
                <div className="space-y-3">
                    {[
                        { text: 'Enviar recibo para Carlos Oliveira', type: 'finance' },
                        { text: 'Preparar laudo de Fernanda Costa', type: 'doc' },
                        { text: 'Reunião de supervisão às 18h', type: 'event' },
                    ].map((item, i) => (
                        <div 
                            key={i} 
                            onClick={() => showToast('Lembrete marcado como concluído!', 'success')}
                            className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all duration-200 cursor-pointer border border-transparent hover:border-slate-100 dark:hover:border-slate-600 transform hover:translate-x-1"
                        >
                            <div className={`mt-0.5 w-2 h-2 rounded-full ${item.type === 'finance' ? 'bg-amber-400' : item.type === 'doc' ? 'bg-sky-400' : 'bg-purple-400'}`}></div>
                            <span className="text-sm text-slate-600 dark:text-slate-300 leading-snug">{item.text}</span>
                        </div>
                    ))}
                </div>
                <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full mt-4 text-xs"
                    onClick={() => showToast('Adicionar novo lembrete', 'info')}
                >
                    Adicionar Lembrete
                </Button>
            </Card>
            
            <div className="bg-sky-600 dark:bg-sky-700 rounded-xl p-6 text-white shadow-lg shadow-sky-200 dark:shadow-none transition-transform hover:scale-[1.02] duration-300">
                <h3 className="font-semibold text-lg mb-2">Precisa de ajuda com as anotações?</h3>
                <p className="text-sky-100 text-sm mb-4">Utilize nossa IA para estruturar as evoluções dos pacientes.</p>
                <Button 
                    className="bg-white text-sky-700 hover:bg-sky-50 w-full border-0 shadow-sm"
                    onClick={() => {
                        navigate('/pacientes');
                        showToast('Selecione um paciente para usar a IA', 'info');
                    }}
                >
                    Experimentar Agora
                </Button>
            </div>
        </div>
      </div>
    </div>
  );
};