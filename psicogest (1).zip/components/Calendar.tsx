import React from 'react';
import { Card, Button, Badge } from './UI';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useNavigate } from 'react-router-dom';

const daysOfWeek = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
const timeSlots = Array.from({ length: 11 }, (_, i) => i + 8); // 8:00 to 18:00

// Simple Mock data specifically for calendar
const weeklyAppointments = [
    { dayIndex: 0, hour: 9, name: 'Mariana Silva', type: 'Online' },
    { dayIndex: 0, hour: 14, name: 'João Pedro', type: 'Presencial' },
    { dayIndex: 1, hour: 10, name: 'Carlos Oliveira', type: 'Presencial' },
    { dayIndex: 2, hour: 11, name: 'Ana Souza', type: 'Online' },
    { dayIndex: 3, hour: 15, name: 'Roberto Lima', type: 'Online' },
    { dayIndex: 4, hour: 9, name: 'Fernanda Costa', type: 'Online' },
    { dayIndex: 4, hour: 16, name: 'Lucas Mendes', type: 'Presencial' },
];

export const CalendarView: React.FC = () => {
    const { showToast } = useToast();
    const navigate = useNavigate();

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Agenda</h2>
                <div className="flex items-center gap-3">
                    <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-1">
                        <button className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500 dark:text-slate-400" onClick={() => showToast('Semana anterior', 'info')}><ChevronLeft size={20} /></button>
                        <span className="px-4 font-medium text-slate-700 dark:text-slate-200 text-sm">Outubro 2023</span>
                        <button className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500 dark:text-slate-400" onClick={() => showToast('Próxima semana', 'info')}><ChevronRight size={20} /></button>
                    </div>
                    <div className="flex bg-slate-100 dark:bg-slate-700 p-1 rounded-lg">
                        <button className="px-3 py-1 bg-white dark:bg-slate-600 shadow-sm rounded-md text-sm font-medium text-slate-800 dark:text-slate-100">Semana</button>
                        <button className="px-3 py-1 text-sm font-medium text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200" onClick={() => showToast('Visualização mensal em breve', 'info')}>Mês</button>
                    </div>
                    <Button className="gap-2" onClick={() => navigate('/novo-agendamento')}><Plus size={18} /> Novo</Button>
                </div>
            </div>

            <Card className="overflow-x-auto min-w-[800px]">
                <div className="grid grid-cols-8 divide-x divide-slate-100 dark:divide-slate-700 min-w-full">
                    {/* Time Column */}
                    <div className="col-span-1">
                        <div className="h-12 bg-slate-50 dark:bg-slate-800 border-b border-slate-100 dark:border-slate-700"></div>
                        {timeSlots.map(hour => (
                            <div key={hour} className="h-20 border-b border-slate-100 dark:border-slate-700 flex items-start justify-center pt-2">
                                <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">{hour}:00</span>
                            </div>
                        ))}
                    </div>

                    {/* Days Columns */}
                    {daysOfWeek.map((day, dayIdx) => (
                        <div key={day} className="col-span-1">
                            {/* Header */}
                            <div className="h-12 bg-slate-50 dark:bg-slate-800 border-b border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center">
                                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">{day}</span>
                                <span className={`text-sm font-bold ${dayIdx === 0 ? 'text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-900/40 w-6 h-6 rounded-full flex items-center justify-center' : 'text-slate-800 dark:text-slate-200'}`}>
                                    {23 + dayIdx}
                                </span>
                            </div>

                            {/* Slots */}
                            {timeSlots.map(hour => {
                                const apt = weeklyAppointments.find(a => a.dayIndex === dayIdx && a.hour === hour);
                                return (
                                    <div key={`${day}-${hour}`} className="h-20 border-b border-slate-50 dark:border-slate-700 p-1 relative group hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                                        {apt && (
                                            <div 
                                                onClick={() => showToast(`Agendamento de ${apt.name}`, 'info')}
                                                className={`h-full w-full rounded-md p-2 text-xs flex flex-col justify-between border-l-2 cursor-pointer transition-all hover:scale-[1.02] hover:shadow-md ${
                                                apt.type === 'Online' 
                                                ? 'bg-sky-50 dark:bg-sky-900/30 border-sky-400 text-sky-700 dark:text-sky-300' 
                                                : 'bg-emerald-50 dark:bg-emerald-900/30 border-emerald-400 text-emerald-700 dark:text-emerald-300'
                                            }`}>
                                                <span className="font-semibold truncate">{apt.name}</span>
                                                <span className="opacity-75">{apt.type}</span>
                                            </div>
                                        )}
                                        {!apt && (
                                            <button 
                                                onClick={() => navigate('/novo-agendamento')}
                                                className="absolute inset-0 w-full h-full opacity-0 group-hover:opacity-100 flex items-center justify-center"
                                            >
                                                <Plus size={16} className="text-sky-400" />
                                            </button>
                                        )}
                                    </div>
                                )
                            })}
                        </div>
                    ))}
                </div>
            </Card>
        </div>
    );
};