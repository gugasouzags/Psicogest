import React, { useState } from 'react';
import { Card, Button, Input, TextArea, Badge } from './UI';
import { Search, MoreHorizontal, FileText, Calendar as CalendarIcon, Phone, Mail, Sparkles, Check, ChevronLeft, Plus, Save } from 'lucide-react';
import { Patient, ClinicalNote } from '../types';
import { refineClinicalNote } from '../services/geminiService';
import { useToast } from '../contexts/ToastContext';
import { useNotification } from '../contexts/NotificationContext';

// Mock Data
const INITIAL_PATIENTS: Patient[] = [
    { id: '1', name: 'Mariana Silva', email: 'mariana@email.com', phone: '(11) 99999-9999', status: 'Active', notes: 'Paciente encaminhada por neurologista.', lastSession: '2023-10-20' },
    { id: '2', name: 'Carlos Oliveira', email: 'carlos@email.com', phone: '(11) 98888-8888', status: 'Active', notes: 'Trabalhando questões de ansiedade social.', lastSession: '2023-10-21' },
    { id: '3', name: 'Fernanda Costa', email: 'fernanda@email.com', phone: '(21) 97777-7777', status: 'Inactive', notes: 'Pausa no tratamento por viagem.', lastSession: '2023-09-15' },
];

const INITIAL_NOTES: ClinicalNote[] = [
    { id: 'n1', patientId: '1', date: '2023-10-20', content: 'Paciente relatou melhora no sono. Discutimos estratégias de coping para o trabalho.', isPrivate: true },
    { id: 'n2', patientId: '1', date: '2023-10-13', content: 'Início do protocolo de TCC para insônia.', isPrivate: true },
];

export const Patients: React.FC = () => {
    const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
    const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
    const [view, setView] = useState<'list' | 'detail' | 'create'>('list');
    const [notes, setNotes] = useState<ClinicalNote[]>(INITIAL_NOTES);
    
    // State for New Note (Detail View)
    const [newNote, setNewNote] = useState('');
    const [isThinking, setIsThinking] = useState(false);

    // State for New Patient (Create View)
    const [newPatientData, setNewPatientData] = useState({
        name: '',
        email: '',
        phone: '',
        notes: ''
    });
    
    const { showToast } = useToast();
    const { notifyAdmin } = useNotification();

    const handlePatientClick = (p: Patient) => {
        setSelectedPatient(p);
        setView('detail');
    };

    const handleBack = () => {
        setView('list');
        setSelectedPatient(null);
        setNewNote('');
        setNewPatientData({ name: '', email: '', phone: '', notes: '' });
    };

    const handleSaveNewPatient = () => {
        if (!newPatientData.name || !newPatientData.email) {
            showToast('Nome e Email são obrigatórios.', 'error');
            return;
        }

        const newPatient: Patient = {
            id: Date.now().toString(),
            name: newPatientData.name,
            email: newPatientData.email,
            phone: newPatientData.phone,
            status: 'Active',
            notes: newPatientData.notes,
            lastSession: '-'
        };

        setPatients([newPatient, ...patients]);
        showToast('Paciente cadastrado! Notificando via WhatsApp...', 'success');
        
        // Notify via WhatsApp
        notifyAdmin(
            'Novo Paciente Cadastrado',
            `👤 Nome: ${newPatientData.name}\n📧 Email: ${newPatientData.email}\n📞 Telefone: ${newPatientData.phone || 'N/A'}`
        );

        handleBack();
    };

    const handleAIRefine = async () => {
        if (!newNote.trim()) return;
        setIsThinking(true);
        const refined = await refineClinicalNote(newNote);
        setNewNote(refined);
        setIsThinking(false);
        showToast('Texto organizado com sucesso!', 'success');
    };

    const handleSaveNote = () => {
        if (!selectedPatient || !newNote.trim()) return;

        const note: ClinicalNote = {
            id: Math.random().toString(36).substr(2, 9),
            patientId: selectedPatient.id,
            date: new Date().toISOString(),
            content: newNote,
            isPrivate: true
        };

        setNotes(prev => [note, ...prev]);
        setNewNote('');
        showToast('Evolução salva com sucesso!', 'success');
    };

    // --- CREATE VIEW ---
    if (view === 'create') {
        return (
            <div className="space-y-6 animate-in fade-in duration-300">
                <div className="flex items-center justify-between">
                    <button onClick={handleBack} className="flex items-center gap-1 text-slate-500 dark:text-slate-400 hover:text-sky-600 transition-colors text-sm font-medium">
                        <ChevronLeft size={16} /> Voltar para lista
                    </button>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Novo Paciente</h2>
                </div>

                <div className="max-w-2xl mx-auto">
                    <Card>
                        <div className="space-y-5">
                            <div className="flex items-center gap-4 mb-2">
                                <div className="w-16 h-16 bg-sky-100 dark:bg-sky-900/50 rounded-full flex items-center justify-center text-sky-700 dark:text-sky-300 font-bold text-2xl">
                                    {newPatientData.name ? newPatientData.name.charAt(0).toUpperCase() : '?'}
                                </div>
                                <div className="flex-1">
                                    <h3 className="font-semibold text-slate-700 dark:text-slate-200">Dados Cadastrais</h3>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Preencha as informações básicas do paciente.</p>
                                </div>
                            </div>

                            <Input 
                                label="Nome Completo *" 
                                placeholder="Ex: João da Silva"
                                value={newPatientData.name}
                                onChange={e => setNewPatientData({...newPatientData, name: e.target.value})}
                            />
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input 
                                    label="Email *" 
                                    type="email"
                                    placeholder="exemplo@email.com"
                                    value={newPatientData.email}
                                    onChange={e => setNewPatientData({...newPatientData, email: e.target.value})}
                                />
                                <Input 
                                    label="Telefone" 
                                    placeholder="(00) 00000-0000"
                                    value={newPatientData.phone}
                                    onChange={e => setNewPatientData({...newPatientData, phone: e.target.value})}
                                />
                            </div>

                            <TextArea 
                                label="Observações Iniciais / Motivo do Encaminhamento"
                                placeholder="Descreva brevemente o motivo da consulta ou encaminhamento..."
                                rows={4}
                                value={newPatientData.notes}
                                onChange={e => setNewPatientData({...newPatientData, notes: e.target.value})}
                            />
                            
                            <div className="pt-4 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-700 mt-4">
                                <Button variant="secondary" onClick={handleBack}>Cancelar</Button>
                                <Button onClick={handleSaveNewPatient} className="gap-2">
                                    <Save size={18} /> Salvar Paciente
                                </Button>
                            </div>
                        </div>
                    </Card>
                </div>
            </div>
        );
    }

    // --- LIST VIEW ---
    if (view === 'list') {
        return (
            <div className="space-y-6">
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Pacientes</h2>
                    <Button className="gap-2" onClick={() => setView('create')}>
                        <Plus size={18} /> Novo Paciente
                    </Button>
                </div>

                <div className="flex gap-4 mb-6">
                    <Input placeholder="Buscar por nome, email..." className="max-w-md" />
                    <select className="border border-slate-200 dark:border-slate-600 rounded-lg px-3 py-2 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500">
                        <option>Todos os Status</option>
                        <option>Ativos</option>
                        <option>Inativos</option>
                    </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {patients.map(patient => (
                        <Card key={patient.id} className="hover:border-sky-200 dark:hover:border-sky-700 transition-colors cursor-pointer group" >
                           <div onClick={() => handlePatientClick(patient)}>
                                <div className="flex justify-between items-start mb-4">
                                    <div className="w-12 h-12 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center text-slate-500 dark:text-slate-400 font-bold text-lg">
                                        {patient.name.charAt(0)}
                                    </div>
                                    <Badge color={patient.status === 'Active' ? 'green' : 'gray'}>
                                        {patient.status === 'Active' ? 'Ativo' : 'Inativo'}
                                    </Badge>
                                </div>
                                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">{patient.name}</h3>
                                <div className="space-y-2 mt-4">
                                    <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                                        <Mail size={14} /> {patient.email}
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                                        <Phone size={14} /> {patient.phone}
                                    </div>
                                     <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                                        <CalendarIcon size={14} /> Última sessão: {patient.lastSession}
                                    </div>
                                </div>
                           </div>
                           <div className="mt-4 pt-4 border-t border-slate-50 dark:border-slate-700 flex justify-end">
                                <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handlePatientClick(patient); }}>Ver Prontuário</Button>
                           </div>
                        </Card>
                    ))}
                </div>
            </div>
        );
    }

    // --- DETAIL VIEW ---
    return (
        <div className="space-y-6 animate-in fade-in duration-300">
            <button onClick={handleBack} className="flex items-center gap-1 text-slate-500 dark:text-slate-400 hover:text-sky-600 transition-colors text-sm font-medium">
                <ChevronLeft size={16} /> Voltar para lista
            </button>

            <div className="flex flex-col lg:flex-row gap-6">
                {/* Left Sidebar: Profile Info */}
                <div className="w-full lg:w-1/3 space-y-6">
                    <Card className="text-center">
                        <div className="w-24 h-24 bg-sky-100 dark:bg-sky-900/50 rounded-full flex items-center justify-center text-sky-700 dark:text-sky-300 font-bold text-3xl mx-auto mb-4">
                            {selectedPatient?.name.charAt(0)}
                        </div>
                        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">{selectedPatient?.name}</h2>
                        <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">Paciente desde Out/2023</p>
                        
                        <div className="flex justify-center gap-2 mb-6">
                             <Button size="sm" variant="outline" onClick={() => showToast('Ligando para paciente...', 'info')}><Phone size={16}/></Button>
                             <Button size="sm" variant="outline" onClick={() => showToast('Abrindo cliente de email...', 'info')}><Mail size={16}/></Button>
                        </div>

                        <div className="text-left space-y-4 border-t border-slate-100 dark:border-slate-700 pt-4">
                            <div>
                                <label className="text-xs font-semibold text-slate-400 uppercase">Status</label>
                                <div className="mt-1"><Badge color="green">Em tratamento</Badge></div>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-slate-400 uppercase">Anotações Gerais</label>
                                <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">{selectedPatient?.notes}</p>
                            </div>
                        </div>
                    </Card>
                </div>

                {/* Right Content: Notes & History */}
                <div className="flex-1 space-y-6">
                    {/* New Note Input Area */}
                    <Card title="Nova Evolução">
                        <div className="relative">
                            <TextArea 
                                rows={6} 
                                placeholder="Digite as anotações da sessão aqui..." 
                                value={newNote}
                                onChange={(e) => setNewNote(e.target.value)}
                                className="resize-none pr-12 text-base leading-relaxed"
                            />
                             {/* AI Button absolute positioned inside or below */}
                            <div className="flex justify-between items-center mt-3">
                                <span className="text-xs text-slate-400">Suas anotações são criptografadas.</span>
                                <div className="flex gap-2">
                                    <Button 
                                        variant="secondary" 
                                        size="sm" 
                                        className="gap-2 text-sky-700 bg-sky-50 hover:bg-sky-100 dark:bg-sky-900/40 dark:text-sky-300 dark:hover:bg-sky-900/60"
                                        onClick={handleAIRefine}
                                        disabled={isThinking || !newNote}
                                    >
                                        {isThinking ? (
                                            <>Pensando...</>
                                        ) : (
                                            <><Sparkles size={16} /> Organizar com IA</>
                                        )}
                                    </Button>
                                    <Button size="sm" disabled={!newNote} onClick={handleSaveNote}>Salvar Evolução</Button>
                                </div>
                            </div>
                        </div>
                    </Card>

                    {/* History List */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Histórico Clínico</h3>
                        {notes
                            .filter(n => n.patientId === selectedPatient?.id)
                            .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                            .map((note) => (
                            <div key={note.id} className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm relative pl-6 animate-in slide-in-from-top-2 duration-300">
                                <div className="absolute left-0 top-6 bottom-6 w-1 bg-sky-400 rounded-r-full"></div>
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                                        <CalendarIcon size={14} className="text-slate-400" /> 
                                        {new Date(note.date).toLocaleDateString()}
                                    </span>
                                    <span className="text-xs text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700 px-2 py-1 rounded">Sessão</span>
                                </div>
                                <p className="text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                                    {note.content}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};