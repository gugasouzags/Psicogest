
export enum AppointmentStatus {
  Scheduled = 'Agendado',
  Completed = 'Realizado',
  Canceled = 'Cancelado',
  NoShow = 'Não Compareceu'
}

export enum PaymentStatus {
  Paid = 'Pago',
  Pending = 'Pendente',
  Overdue = 'Atrasado'
}

export interface Patient {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  nextSession?: string; // ISO Date
  lastSession?: string; // ISO Date
  status: 'Active' | 'Inactive' | 'Archived';
  notes: string; // General internal notes
}

export interface ClinicalNote {
  id: string;
  patientId: string;
  date: string;
  content: string;
  isPrivate: boolean;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  date: string; // ISO Date string
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  type: 'Online' | 'Presencial';
  status: AppointmentStatus;
  paymentStatus: PaymentStatus;
  value: number;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'Income' | 'Expense';
  status: PaymentStatus;
  patientName?: string;
}

// AI Service Types
export interface AIResponse {
  text: string;
}

// Notification Types
export interface NotificationSettings {
  psychologist: {
    enabled: boolean;
    advanceTime: number; // in minutes
    channel: 'push' | 'email' | 'both';
    adminPhoneNumber: string; // Added for WhatsApp Admin Notifications
  };
  patient: {
    enabled: boolean;
    advanceTime: number; // in minutes (e.g., 1440 for 24h)
    channel: 'email' | 'sms' | 'whatsapp';
  };
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  date: string; // ISO Date
  read: boolean;
  type: 'appointment' | 'system' | 'finance';
}

// Subscription Types
export type PlanType = 'free' | 'pro' | 'enterprise';
export type SubscriptionStatus = 'active' | 'inactive' | 'past_due' | 'canceled';